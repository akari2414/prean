# -*- coding: utf-8 -*-
import scrapy


class ToScrapeSpiderXPath(scrapy.Spider):
    name = 'toscrape-xpath'
    start_urls = [
        'http://quotes.toscrape.com/',
    ]

    def parse(self, response):
        for quote in response.xpath('//div[@class="quote"]'):
            about_url = quote.xpath('.//small[@class="author"]/../a/@href').extract_first()
            request = scrapy.Request(response.urljoin(about_url),
                                     callback=self.parse_about)

            request.cb_kwargs['text'] = quote.xpath('./span[@class="text"]/text()').extract_first()
            request.cb_kwargs['author'] = quote.xpath('.//small[@class="author"]/text()').extract_first()
            request.cb_kwargs['tags'] = quote.xpath('.//div[@class="tags"]/a[@class="tag"]/text()').extract()

            yield request

        next_page_url = response.xpath('//li[@class="next"]/a/@href').extract_first()
        if next_page_url is not None:
            yield scrapy.Request(response.urljoin(next_page_url))


    def parse_about(self, response, text, author, tags):

        for sel in response.xpath('//div[@class="author-details"]'):
            born = sel.xpath('./p/span[@class="author-born-date"]/text()').extract_first() + ' ' + \
                   sel.xpath('./p/span[@class="author-born-location"]/text()').extract_first()

            yield {
                'text': text,
                'author': {
                    'name': author,
                    'born': born,
                    'description': sel.xpath('./p/span[@class="author-description"]/text()').extract_first()
                },
                'tags': tags
            }
