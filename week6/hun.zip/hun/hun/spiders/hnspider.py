# -*- coding: utf-8 -*-
import scrapy


class hnSpider(scrapy.Spider):
    name = "hnSpider"
    start_urls = [
        'https://www.brainyquote.com/authors/nicole-scherzinger-quotes',
    ]

    def parse(self, response):
        for lists in response.xpath('//*[@class="qll-bg"]'):
            yield {
                'text': lists.xpath('.//div[@class="clearfix"]/a/text()').extract_first(),
                'author': lists.xpath('.//div[@class="clearfix"]/div/a/text()').extract_first(),
                'tags': lists.xpath('.//div[@class="kw-box"]/a/text()').extract()
            }